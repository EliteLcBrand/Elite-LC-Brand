# ÉLITE — Boutique moda

Sito demo responsive per una boutique di abbigliamento premium.

## Funzioni incluse
- Homepage luxury
- Catalogo prodotti
- Filtri per categoria
- Carrello con salvataggio nel browser
- Quantità, rimozione articoli e totale
- Newsletter demo
- Layout ottimizzato per smartphone

## Come aprirlo
Apri `index.html` con un browser.

## Prima della pubblicazione
- Sostituisci nome, testi, foto e prodotti.
- Collega il checkout a Stripe, PayPal o Shopify.
- Aggiungi pagine legali, cookie banner e privacy policy.
- Usa solo marchi, immagini e descrizioni per cui possiedi i diritti.
